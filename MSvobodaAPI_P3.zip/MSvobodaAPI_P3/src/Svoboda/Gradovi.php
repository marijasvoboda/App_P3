<?php

namespace Svoboda;

/**
 * @Entity @Table(name="gradovi")
 **/


class Gradovi
{
    /** @id @Column(type="integer") @GeneratedValue **/
    protected $sifra;

    /**
    * @Column(type="string")
    */
    private $nazivDrzave;

     /**
    * @Column(type="string")
    */
    private $nazivGrada;


    /**
    * @Column(type="string")
    */
    private $godina;

    /**
    * @Column(type="string")
    */
    private $biljeska;

    public function getSifra(){
      return $this->sifra;
    }
  
    public function setSifra($sifra){
      $this->sifra = $sifra;
    }
  
    public function getNazivDrzave(){
      return $this->nazivDrzave;
    }
  
    public function setNazivDrzave($nazivDrzave){
      $this->nazivDrzave = $nazivDrzave;
    }
  
    public function getNazivGrada(){
      return $this->nazivGrada;
    }
  
    public function setNazivGrada($nazivGrada){
      $this->nazivGrada = $nazivGrada;
    }
  
    public function getGodina(){
      return $this->godina;
    }
  
    public function setGodina($godina){
      $this->godina = $godina;
    }
  
    public function getBiljeska(){
      return $this->biljeska;
    }
  
    public function setBiljeska($biljeska){
      $this->biljeska = $biljeska;

    }
    
  public function setPodaci($podaci)
	{
		foreach($podaci as $kljuc => $vrijednost){
			$this->{$kljuc} = $vrijednost;
		}
	}

}



?>
