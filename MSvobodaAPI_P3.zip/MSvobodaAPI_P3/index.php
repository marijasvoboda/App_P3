<?php
require 'vendor/autoload.php';
require 'bootstrap.php';
use Svoboda\Gradovi;
use Svoboda\Projekt;
use Composer\Autoload\ClassLoader;

Flight::route('/', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('https://oziz.ffos.hr/nastava20192020/msvoboda_19/msvoboda.rdf');
  $info = $foaf->dump();
  echo "<h2>Ontologija za P3 zadatak:</h2> <br/><br/>" . $info;
});

Flight::route('GET /search', function(){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Svoboda\Gradovi');
  $zapisi = $repozitorij->findAll();
  echo $doctrineBootstrap->getJson($zapisi);
});

Flight::route('GET /fill', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('https://oziz.ffos.hr/nastava20192020/msvoboda_19/msvoboda.rdf');
  foreach ($foaf->resources() as $resource) {

    $name = $foaf->get($resource, 'foaf:name');

    $title = $foaf->get($resource, 'dc:title'); 

    if($name != ''){

      $i = 0;
      $annotations = "";

      
      $description = $foaf->get($resource, 'dc:description'); 

      foreach ($resource->properties() as $key) {
          $annotations .= $key . ': ' . $foaf->get($resource, $key) . "\n"; 
      }

      $gradovi = new Gradovi();
      $gradovi->setPodaci(Flight::request()->data);


      $gradovi->setNazivGrada($name); 
      $gradovi->setNazivDrzave($title); 
      $gradovi->setGodina($description);
      $gradovi->setBiljeska($annotations);

      $doctrineBootstrap = Flight::entityManager();
      $em = $doctrineBootstrap->getEntityManager();

      $em->persist($gradovi);
      $em->flush();

    
    }
  }

  echo "U bazu je uspješno unijeta ontologija.";

});

Flight::route('GET /search/@name', function($name){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Svoboda\Gradovi');
  $zapisi = $repozitorij->createQueryBuilder('p')
                        ->where('p.nazivGrada LIKE :nazivGrada')
                        ->setParameter('nazivGrada', '%'.$name.'%')
                        ->getQuery()
                        ->getResult();  
  echo $doctrineBootstrap->getJson($zapisi);

});

$cl = new ClassLoader('Svoboda', __DIR__, '/src');
$cl->register();
require_once 'bootstrap.php';
Flight::register('entityManager', 'DoctrineBootstrap');

Flight::start();

