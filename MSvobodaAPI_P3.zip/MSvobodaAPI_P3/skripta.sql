create database msvoboda_19 default character set utf8;
use msvoboda_19;
create table gradovi(
    sifra int not null primary key auto_increment,
    nazivDrzave varchar(255) not null,
    nazivGrada varchar(255) not null,
    godina varchar(255) not null,
    biljeska varchar(255) not null
);
insert into gradovi(nazivDrzave, nazivGrada, godina, biljeska) 
values ("Test", "Test", "Test", "Test");
